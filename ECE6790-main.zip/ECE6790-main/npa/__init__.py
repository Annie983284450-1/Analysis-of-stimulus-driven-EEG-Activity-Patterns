from .version import __version__
from .npa import NPA