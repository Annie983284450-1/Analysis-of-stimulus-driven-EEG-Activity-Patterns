# ECE6790
ECE 6790 Group Project


Course Project for ECE 6790 Georgia Tech


1. Add NPA to the directory: https://github.com/crocodoyle/npa
2. Create a directory called ds00017 in the root and keep the data in the ds00017 folder
3. Create and activate the virtual environment: 
            a. conda env create -f environment.yml -n ee6790
            b. conda activate ece6790
            c. conda install -c conda-forge shap
4. Run the classifier.py as follows:
            python3 classifier.py
